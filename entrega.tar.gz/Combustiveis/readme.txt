
AUTOR : ELIVELTON DA SILVA DE MORAES
 
DESCRIÇÃO : O scrip tem como função trazer o preço medio dos combustiveis assim como o seu menor preço nos municipios da base de dados, seu uso se faz chamando ./combustiveis.sh seguido da sigla do estado, municipio, tipo de combustivel.
